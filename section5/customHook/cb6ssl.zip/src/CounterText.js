export const CounterText = ({ count }) => (
  <p>
    現在のカウント数：<b>{count}</b>
  </p>
);
